import express from "express";

const router = express.Router();
let supportMessages = [];

// משתמש שולח הודעה
router.post("/send", (req, res) => {
  supportMessages.push({
    from: "user",
    text: req.body.text,
    createdAt: Date.now()
  });

  res.json({ msg: "Message sent" });
});

// מנהל מגיב
router.post("/reply", (req, res) => {
  supportMessages.push({
    from: "admin",
    text: req.body.text,
    createdAt: Date.now()
  });

  res.json({ msg: "Reply sent" });
});

// קבלת היסטוריית תמיכה
router.get("/history", (req, res) => {
  res.json(supportMessages);
});

export default router;
