import express from "express";

const router = express.Router();

let messages = [];

router.post("/send", (req, res) => {
  const { userId, text } = req.body;

  messages.push({
    userId,
    text,
    createdAt: Date.now()
  });

  res.json({ msg: "Sent" });
});

router.get("/messages", (req, res) => {
  res.json(messages);
});

export default router;
