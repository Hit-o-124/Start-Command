import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  email: String,
  password: String,
  balance: { type: Number, default: 0 },
  tasksCompleted: { type: Number, default: 0 },
  paymentMethods: {
    stripe: { fullName: String, iban: String },
    paypal: { email: String },
    binance: { payId: String }
  },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model("User", userSchema);
