import express from "express";
import Withdraw from "../models/withdraw.js";
import User from "../models/users.js";

const router = express.Router();

// יצירת בקשת משיכה
router.post("/request", async (req, res) => {
  const { userId, amount } = req.body;

  const user = await User.findById(userId);

  if (!user) return res.json({ msg: "User not found" });
  if (user.balance < amount) return res.json({ msg: "Insufficient balance" });

  const withdraw = new Withdraw({
    userId,
    amount,
    method: user.paymentMethods.stripe
      ? "stripe"
      : user.paymentMethods.paypal
      ? "paypal"
      : "binance"
  });

  await withdraw.save();

  user.balance -= amount;
  await user.save();

  res.json({ msg: "Withdraw request created", withdraw });
});

export default router;
