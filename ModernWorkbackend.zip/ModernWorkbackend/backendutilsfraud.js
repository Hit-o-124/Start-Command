export function detectFraud(user, action) {
  let flags = [];

  // חשבון חדש + פעילות גבוהה
  if (Date.now() - user.createdAt.getTime() < 1000 * 60 * 60 * 24) {
    if (user.tasksCompleted > 10) flags.push("Too many tasks for new account");
  }

  // סכום משיכה גבוה מחשוד
  if (action === "withdraw" && user.balance > 5000) {
    flags.push("Large withdraw for new user");
  }

  // משימות בקצב לא אנושי
  if (user.tasksCompleted > 50) {
    flags.push("Possible bot activity");
  }

  return flags;
}
