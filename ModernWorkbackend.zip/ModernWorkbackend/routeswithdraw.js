import express from "express";
import User from "../models/users.js";

const router = express.Router();

router.post("/save", async (req, res) => {
  const { userId, method, data } = req.body;

  const user = await User.findById(userId);
  user.paymentMethods[method] = data;
  await user.save();

  res.json({ msg: "Payment method saved" });
});

export default router;
