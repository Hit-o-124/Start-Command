import express from "express";
import User from "../models/users.js";
import Task from "../models/tasks.js";
import Withdraw from "../models/withdraw.js";

const router = express.Router();

// סטטיסטיקות ראשיות
router.get("/stats", async (req, res) => {
  const users = await User.countDocuments();
  const tasks = await Task.countDocuments();
  const totalEarnings = (await User.find()).reduce((sum, u) => sum + u.balance, 0);
  const pendingWithdraws = await Withdraw.countDocuments({ status: "pending" });

  res.json({
    users,
    tasks,
    totalEarnings,
    pendingWithdraws
  });
});

export default router;
