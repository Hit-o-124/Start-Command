import express from "express";
import Task from "../models/tasks.js";

const router = express.Router();

// הוספת משימה
router.post("/add", async (req, res) => {
  const { title, type, reward } = req.body;

  const task = new Task({ title, type, reward });
  await task.save();

  res.json({ msg: "Task added", task });
});

// מחיקת משימה
router.post("/delete", async (req, res) => {
  await Task.deleteOne({ _id: req.body.id });
  res.json({ msg: "Task deleted" });
});

// רשימת משימות
router.get("/list", async (req, res) => {
  const tasks = await Task.find();
  res.json(tasks);
});

export default router;
