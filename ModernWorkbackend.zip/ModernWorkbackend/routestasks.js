import express from "express";
import Task from "../models/tasks.js";
import User from "../models/users.js";

const router = express.Router();

// קבל משימה רנדומלית
router.get("/random", async (req, res) => {
  const tasks = await Task.find();
  const random = tasks[Math.floor(Math.random() * tasks.length)];
  res.json(random);
});

// סיום משימה
router.post("/complete", async (req, res) => {
  const { userId, reward } = req.body;

  await User.updateOne(
    { _id: userId },
    {
      $inc: {
        balance: reward,
        tasksCompleted: 1
      }
    }
  );

  res.json({ msg: "Task completed!" });
});

export default router;
