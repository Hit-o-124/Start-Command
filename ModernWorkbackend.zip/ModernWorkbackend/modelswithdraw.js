import mongoose from "mongoose";

const withdrawSchema = new mongoose.Schema({
  userId: String,
  amount: Number,
  method: String,
  status: { type: String, default: "pending" },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model("Withdraw", withdrawSchema);
